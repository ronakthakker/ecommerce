<style type="text/css">
	.i_user{
	padding: 10px;
	font-size: 18px;
	}
</style>
<div class="leftpanel">
	<div class="media profile-left">
		
		<div class="media-body">
			<h4 class="media-heading">David Raphel</h4>
			<small class="text-muted">Admin Panel</small>
		</div>
	</div><!-- media -->
	<ul class="nav nav-pills nav-stacked">
		<!-- <li class="active"><a href="index.html"><i class="fa fa-home"></i> <span>Dashboard</span></a></li> -->
		<!-- <li class="parent"><a href=""><i class="fa fa-bars"></i> <span>Tables</span></a>
			<ul class="children">
			<li><a href="basic-tables.html">Basic Tables</a></li>
			<li><a href="data-tables.html">Data Tables</a></li>
			</ul>
		</li> -->
		<!-- <li><a href="product_category_list.php"><span class="pull-right"><i class="fa fa-chevron-right"></i></span><i class="fa fa-align-justify"></i> <span>Product Categories</span></a></li> -->
		<!-- <li <?php if($base == 'dashboard'){ ?> class="active" <?php } ?>><a href="dashboard.php"><span class="pull-right"><i class="fa fa-chevron-right"></i></span><i class="fa fa-align-justify yellow_color"></i> <span>Dashboard</span></a></li>
			<li class="parent <?php if($base == 'category_list' || $base == 'sub_category_list' || $base == 'sub_category_add' || $base == 'property_list' || $base == 'property_add' || $base == 'brand_list' || $base == 'brand_add'){ ?> active <?php } ?>"><a href=""><i class="fa fa-edit yellow_color"></i> <span>Masters</span></a>
			<ul class="children">
			<li <?php if($base == 'brand_list'){ ?> class="active" <?php } ?>><a href="brand_list.php">Brand</a></li>
			<li <?php if($base == 'category_list'){ ?> class="active" <?php } ?>><a href="category_list.php">Category</a></li>
			<li <?php if($base == 'sub_category_list' || $base == 'sub_category_add'){ ?> class="active" <?php } ?>><a href="sub_category_list.php">Subcategory</a></li>
			<li <?php if($base == 'property_list' || $base == 'property_add'){ ?> class="active" <?php } ?>><a href="property_list.php">Product Properties Master</a></li>
			</ul>
			</li>
			<li <?php if($base == 'product_list' || $base == 'product_add'){ ?> class="active" <?php } ?>><a href="product_list.php"><span class="pull-right"><i class="fa fa-chevron-right"></i></span><i class="fa fa-pencil"></i> <span>Products</span></a></li>
			<li <?php if($base == 'order_list'){ ?> class="active" <?php } ?>><a href="order_list.php"><span class="pull-right"><i class="fa fa-chevron-right"></i></span><i class="fa fa-shopping-cart yellow_color"></i> <span>Orders</span></a></li>
			<li <?php if($base == 'user_list'){ ?> class="active" <?php } ?>><a href="users_list.php"><span class="pull-right"><i class="fa fa-chevron-right"></i></span><i class="fa fa-user yellow_color"></i> <span>Users</span></a></li>
		<li <?php if($base == 'ref_user_list'){ ?> class="active" <?php } ?>><a href="ref_users_list.php"><span class="pull-right"><i class="fa fa-chevron-right"></i></span><i class="fa fa-user yellow_color"></i> <span>Referral Users</span></a></li> -->
		
		
		<li <?php if($base == 'slider_list'){ ?> class="active" <?php } ?>><a href="slider_list.php"><span class="pull-right"><i class="fa fa-chevron-right"></i></span><i class="fa fa-picture-o yellow_color"></i> <span>Slider Master</span></a></li>
	
		
		
		<li class="parent <?php if($base == 'category_list' || $base == 'category_add' || $base == 'sub_category_list' || $base == 'sub_category_add' || $base == 'material_list' || $base == 'material_add' || $base == 'product_list' || $base == 'product_add'){ ?> active <?php } ?>"><a href=""><i class="fa fa-edit yellow_color"></i> <span>Product Master</span></a>
		
		
			<ul class="children">
				<li <?php if($base == 'category_list' || $base == 'category_add'){ ?> class="active" <?php } ?>><a href="category_list.php">Category Master</a></li>
				<li <?php if($base == 'sub_category_list' || $base == 'sub_category_add'){ ?> class="active" <?php } ?>><a href="sub_category_list.php">sub category List</a></li>
				<li <?php if($base == 'material_list' || $base == 'material_add'){ ?> class="active" <?php } ?>><a href="material_list.php">material List</a></li>
				<li <?php if($base == 'product_list' || $base == 'product_add'){ ?> class="active" <?php } ?>><a href="product_list.php">Product List</a></li>
			</ul> 
		</li>
		
		
	</ul>
	
</div>