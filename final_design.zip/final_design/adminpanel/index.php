<html>
	<head>
		<title>David Raphel </title>
		<script type="text/javascript">
			location.href="login.php";
		</script>
	</head>
</html>