<?php
	session_start(); 
	unset($_SESSION['skinbae_admin_id']);
?>
<script>
	window.location.href='index.php';
</script>
