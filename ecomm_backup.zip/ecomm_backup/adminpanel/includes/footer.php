<style type="text/css">
	footer {
		position: fixed;
		background: #101010;
		padding: 1%;
		width: 100%;
		bottom: 0;
		z-index: 1000;
	}

</style>
<footer>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12 text-center">

				Daily-Use © <?php echo date('Y', strtotime("now"));?> All Rights Reserved. Powered by <a href="http://onerooftech.com/" target="_blank">OneRoof Technologies LLP.</a>
			</div>
		</div>
	</div>
</footer>
<script src="js/jquery-1.11.1.min.js"></script>
<script src="js/jquery-ui-1.10.3.min.js"></script>
<script src="js/jquery-migrate-1.2.1.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/modernizr.min.js"></script>
<script src="js/pace.min.js"></script>
<script src="js/retina.min.js"></script>
<script src="js/jquery.cookies.js"></script>

<!-- <script src="js/flot/jquery.flot.min.js"></script>
<script src="js/flot/jquery.flot.resize.min.js"></script>
<script src="js/flot/jquery.flot.spline.min.js"></script> -->

<script src="js/jquery.sparkline.min.js"></script>
<script src="js/morris.min.js"></script>
<script src="js/raphael-2.1.0.min.js"></script>
<script src="js/bootstrap-wizard.min.js"></script>
<script src="js/select2.min.js"></script>
<!-- <script src="js/dropzone.min.js"></script> -->
<script src="js/custom.js"></script>

<!-- <script src="js/dashboard.js"></script> -->

