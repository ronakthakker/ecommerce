<html>
	<head>
		<title> Ecomm </title>
		<script type="text/javascript">
			location.href="login.php";
		</script>
	</head>
</html>